export default [
    {
        path: "/saler_tools/hello_world/index",
        component: () => import('~/addon/saler_tools/pages/hello_world/index.vue')
    }
]
