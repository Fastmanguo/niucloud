
/**
 * hello world
 */
export function getHelloWorld() {
    return request.get('saler_tools/hello_world')
}

