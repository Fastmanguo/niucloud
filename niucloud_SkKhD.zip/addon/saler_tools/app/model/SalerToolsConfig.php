<?php
// +----------------------------------------------------------------------
// | 门店管理saas
// +----------------------------------------------------------------------
// | Author  : 琦森 admin@musp.cn
// | DateTime: 2024/11/25 2:54
// +----------------------------------------------------------------------

namespace addon\saler_tools\app\model;

use addon\saler_tools\app\common\BaseModel;

/**
 * 配置存储
 * Class SalerToolsConfig
 * @package addon\saler_tools\app\model
 */
class SalerToolsConfig extends BaseModel
{



}
