<?php
// +----------------------------------------------------------------------
// | 门店管理saas
// +----------------------------------------------------------------------
// | Author  : 琦森 admin@musp.cn
// | DateTime: 2024/12/17 5:13
// +----------------------------------------------------------------------

namespace addon\saler_tools\app\model;

use addon\saler_tools\app\common\BaseModel;

/**
 *
 * Class SalerToolsDict
 * @package addon\saler_tools\app\model
 */
class SalerToolsDict extends BaseModel
{

    protected $name = 'saler_tools_dict';

    protected $pk = 'id';
    

}
