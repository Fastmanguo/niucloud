<?php
// +----------------------------------------------------------------------
// | campus-procurement-mall
// +----------------------------------------------------------------------
// | Author  : 琦森 admin@musp.cn
// | DateTime: 2024/11/19 21:50
// +----------------------------------------------------------------------

namespace addon\saler_tools\app\common;

/**
 *
 * Class BaseService
 * @package addon\saler_tools\app\common
 */
class BaseService extends \core\base\BaseService
{


}
