<?php
// +----------------------------------------------------------------------
// | campus-procurement-mall
// +----------------------------------------------------------------------
// | Author  : 琦森 admin@musp.cn
// | DateTime: 2024/11/20 0:46
// +----------------------------------------------------------------------

namespace addon\saler_tools\app\common;

/**
 *
 * Class BaseApiService
 * @package addon\saler_tools\app\common
 */
class BaseApiService extends \core\base\BaseApiService
{

}
