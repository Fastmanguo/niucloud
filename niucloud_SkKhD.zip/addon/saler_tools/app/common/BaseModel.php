<?php
// +----------------------------------------------------------------------
// | 门店管理saas
// +----------------------------------------------------------------------
// | Author  : 琦森 admin@musp.cn
// | DateTime: 2024/12/10 21:32
// +----------------------------------------------------------------------

namespace addon\saler_tools\app\common;

/**
 *
 * Class BaseModel
 * @package addon\saler_tools\app\common
 */
class BaseModel extends \core\base\BaseModel
{

}
