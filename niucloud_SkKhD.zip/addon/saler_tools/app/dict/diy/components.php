<?php

return [
    'SALER_TOOLS_COMPONENT' => [
        'title' => get_lang('dict_diy.shop_component_type_basic'),
        'list' => [

        ]
    ],

];
