<?php

return [
    'SALER_TOOLS_LINK' => [
        'title' => '',
        'child_list' => [
            [
                'name' => 'SHOP_INDEX',
                'title' => get_lang('dict_diy.shop_link_index'),
                'url' => '/addon/shop/pages/index',
                'is_share' => 1,
                'action' => 'decorate'
            ],
        ]
    ],
];
