<?php
// +----------------------------------------------------------------------
// | 门店管理saas
// +----------------------------------------------------------------------
// | Author  : 琦森 admin@musp.cn
// | DateTime: 2025/1/20 23:22
// +----------------------------------------------------------------------

namespace addon\saler_tools\app\dict\sys;

/**
 * 通知模板
 * Class NotifyTemplateService
 * @package addon\saler_tools\app\dict\sys
 */
class NotifyTemplate
{



}
