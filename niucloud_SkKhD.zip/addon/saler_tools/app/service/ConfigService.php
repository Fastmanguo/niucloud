<?php
// +----------------------------------------------------------------------
// | 门店管理saas
// +----------------------------------------------------------------------
// | Author  : 琦森 admin@musp.cn
// | DateTime: 2024/11/25 2:56
// +----------------------------------------------------------------------

namespace addon\saler_tools\app\service;

/**
 * 配置存储服务
 * Class ConfigService
 * @package addon\saler_tools\app
 */
class ConfigService
{

}
