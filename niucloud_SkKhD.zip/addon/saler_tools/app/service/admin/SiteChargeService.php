<?php
// +----------------------------------------------------------------------
// | 门店管理saas
// +----------------------------------------------------------------------
// | Author  : 琦森 admin@musp.cn
// | DateTime: 2025/2/21 22:30
// +----------------------------------------------------------------------

namespace addon\saler_tools\app\service\admin;

use addon\saler_tools\app\common\BaseAdminService;

/**
 *
 * Class SiteChargeService
 * @package addon\saler_tools\app\service\admin
 */
class SiteChargeService extends BaseAdminService
{

}
