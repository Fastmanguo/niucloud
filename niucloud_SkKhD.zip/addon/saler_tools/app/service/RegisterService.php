<?php
// +----------------------------------------------------------------------
// | 门店管理saas
// +----------------------------------------------------------------------
// | Author  : 琦森 admin@musp.cn
// | DateTime: 2024/11/25 3:18
// +----------------------------------------------------------------------

namespace addon\saler_tools\app\service;

use addon\saler_tools\app\common\BaseAdminService;

/**
 * 商户注册服务
 * Class RegisterService
 * @package addon\saler_tools\app\service
 */
class RegisterService extends BaseAdminService
{

    public function getRegister()
    {

    }

    public function setRegister($data)
    {

    }

}
