<?php
// +----------------------------------------------------------------------
// | 门店管理saas
// +----------------------------------------------------------------------
// | Author  : 琦森 admin@musp.cn
// | DateTime: 2025/3/2 4:27
// +----------------------------------------------------------------------

namespace addon\saler_tools\app\service\sys;

use addon\saler_tools\app\common\BaseAdminService;
use addon\saler_tools\app\dict\sys\SystemDict;
use app\service\core\sys\CoreConfigService;
use stdClass;

/**
 * APP配置
 * Class AppConfigService
 * @package addon\saler_tools\app\service\sys
 */
class AppConfigService extends BaseAdminService
{




}
