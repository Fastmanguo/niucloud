<?php
// +----------------------------------------------------------------------
// | 门店管理saas
// +----------------------------------------------------------------------
// | Author  : 琦森 admin@musp.cn
// | DateTime: 2025/5/16 6:46
// +----------------------------------------------------------------------

namespace addon\saler_tools\app\service\pay;

/**
 * 支付驱动
 * Class CorePaymentService
 * @package addon\saler_tools\app\service\pay
 */
class CorePaymentService
{

}
