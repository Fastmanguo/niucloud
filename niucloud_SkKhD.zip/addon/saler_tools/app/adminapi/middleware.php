<?php
// 全局中间件定义文件
use addon\saler_tools\app\middleware\DatabaseSwitch;

return [
    DatabaseSwitch::class,
];
