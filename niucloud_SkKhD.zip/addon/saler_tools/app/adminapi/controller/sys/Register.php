<?php
// +----------------------------------------------------------------------
// | 门店管理saas
// +----------------------------------------------------------------------
// | Author  : 琦森 admin@musp.cn
// | DateTime: 2024/11/25 3:53
// +----------------------------------------------------------------------

namespace addon\saler_tools\app\adminapi\controller\sys;

use addon\saler_tools\app\common\BaseAdminService;

/**
 * 注册相关
 * Class Register
 * @package addon\saler_tools\app\adminapi\controller\sys
 */
class Register extends BaseAdminService
{

}
