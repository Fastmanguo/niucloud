<?php
// +----------------------------------------------------------------------
// | 门店管理saas
// +----------------------------------------------------------------------
// | Author  : 琦森 admin@musp.cn
// | DateTime: 2025/1/24 0:55
// +----------------------------------------------------------------------

namespace addon\saler_tools\app\adminapi\controller;

use addon\saler_tools\app\common\BaseAdminController;

/**
 * 找回密码
 * Class Retrieve
 * @package addon\saler_tools\app\adminapi\controller
 */
class Retrieve extends BaseAdminController
{



}
