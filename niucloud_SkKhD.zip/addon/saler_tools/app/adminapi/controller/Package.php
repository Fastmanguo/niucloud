<?php
// +----------------------------------------------------------------------
// | 门店管理saas
// +----------------------------------------------------------------------
// | Author  : 琦森 admin@musp.cn
// | DateTime: 2025/1/21 6:16
// +----------------------------------------------------------------------

namespace addon\saler_tools\app\adminapi\controller;

use addon\saler_tools\app\common\BaseAdminController;

/**
 * 包裹管理
 * Class Package
 * @package addon\saler_tools\app\adminapi\controller
 */
class Package extends BaseAdminController
{



}
