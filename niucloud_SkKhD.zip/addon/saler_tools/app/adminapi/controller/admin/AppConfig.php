<?php
// +----------------------------------------------------------------------
// | 门店管理saas
// +----------------------------------------------------------------------
// | Author  : 琦森 admin@musp.cn
// | DateTime: 2025/3/2 4:26
// +----------------------------------------------------------------------

namespace addon\saler_tools\app\adminapi\controller\admin;

use addon\saler_tools\app\common\BaseAdminController;

/**
 * app配置
 * Class AppConfig
 * @package addon\saler_tools\app\adminapi\controller\admin
 */
class AppConfig extends BaseAdminController
{



}
