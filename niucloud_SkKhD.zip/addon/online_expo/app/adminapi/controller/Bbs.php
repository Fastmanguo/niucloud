<?php
// +----------------------------------------------------------------------
// | 门店管理saas
// +----------------------------------------------------------------------
// | Author  : 琦森 admin@musp.cn
// | DateTime: 2025/2/6 1:53
// +----------------------------------------------------------------------

namespace addon\online_expo\app\adminapi\controller;

use addon\saler_tools\app\common\BaseAdminController;

/**
 *
 * Class Bbs
 * @package addon\online_expo\app\adminapi\controller
 */
class Bbs extends BaseAdminController
{



}
