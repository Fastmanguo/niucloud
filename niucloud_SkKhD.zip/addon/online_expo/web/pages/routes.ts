export default [
    {
        path: "/online_expo/hello_world/index",
        component: () => import('~/addon/online_expo/pages/hello_world/index.vue')
    }
]
