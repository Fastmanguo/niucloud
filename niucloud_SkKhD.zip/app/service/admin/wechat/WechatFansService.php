<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的saas管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace app\service\admin\wechat;

use core\base\BaseAdminService;

/**
 * 微信粉丝
 * Class WechatConfigService
 * @package app\service\core\wechat
 */
class WechatFansService extends BaseAdminService
{

//    /**
//     * 新增微信粉丝
//     * @param $data
//     * @return void
//     */
//    public function add($data){
//
//    }
//
//    /**
//     * 更新微信粉丝信息
//     * @param $fans_id
//     * @param $data
//     * @return void
//     */
//    public function update($fans_id, $data){
//
//    }
}